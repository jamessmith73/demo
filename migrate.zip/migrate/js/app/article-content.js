define(["jquery","contentSDK"], function($, contentSDK) {

    let contentServer = "https://oraclemartech-oce0001.cec.ocp.oraclecloud.com";
    let contentVersion = "v1.1";
    let channelToken = "6a1f7f0666a3eacaecba76bd48fff869";
    let contentId = "CORE0CFBAF9231B74DD5A9DB10974C11EDB4";
                   //CORE0CFBAF9231B74DD5A9DB10974C11EDB4
                   // 6a1f7f0666a3eacaecba76bd48fff869
    // https://oraclemartech-oce0001.cec.ocp.oraclecloud.com/documents/assets/view/CORE0CFBAF9231B74DD5A9DB10974C11EDB4
    let contentClient = contentSDK.createDeliveryClient({
        contentServer: contentServer,
        contentVersion: contentVersion,
        channelToken: channelToken
    });

    contentClient.getItem({
        'id': contentId
    }).then(data => {
        return render(data)
    }).catch(err => {
        console.log(err)
    });

   
    
    const render = data => {
      console.log("inside render ");
      $('#title').html(data.name)
      //console.log(data.name);
      $('#abstract').html(data.description)
      //$('#author').html(data.updatedDate)
      //$('#content').html(data.Content)  
      //$('#content').html(data.updatedDate.value)
      $('#content').html(data.fields['starter-blog-post_title'])
      $('#postcontent').html(data.fields['starter-blog-post_content'])
      //$('#postauthor').html(data.fields['starter-blog-post_content.name'])

      let imageURL = contentServer + "/content/published/api/" + contentVersion +
      "/assets/" + data.fields.starter_blog_post_download_media.id + "/native?channelToken=" +
      channelToken;
      console.log (imageURL);

      $('#hero').attr("src", imageURL)
      $('#postedDate').html(data.updatedDate.value)
    } 
    
});

/*
const render = data => {
      $('#title').html(data.name)
      $('#abstract').html(data.description)
      $('#content').html(data.content)
      $('#postedDate').html(data.updatedDate)
    }
    render({
        name: 'Madhus Article Name',
        description: 'This abstract is also generated dynamically!',
        content: '<p>first paragraph</p><p>second paragraph</p><p>third paragraph</p>',
        updatedDate: 'Sept 25th, 2019 '
    })

    render({
        name: 'Madhus Article Name',
        description: 'This abstract is also generated dynamically!',
        content: '<p>first paragraph</p><p>second paragraph</p><p>third paragraph</p>',
        updatedDate: 'Sept 25th, 2019 '
    })
*/
