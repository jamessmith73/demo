requirejs.config({
    "baseUrl": "/js",
    "paths": {
        "app": "./app",
        "contentSDK":"https://oraclemartech-oce0001.cec.ocp.oraclecloud.com/_sitesclouddelivery/renderer/app/sdk/js/content.min",
        "jquery": "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min"
    }
});
require(['app/article-content'])
